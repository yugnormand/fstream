import xbmc
xbmc.executebuiltin("RunPlugin(plugin://plugin.video.fstream/?site=cGui&function=viewInfo)", True)
