# -*- coding: utf-8 -*-
# fStream https://github.com/yugnormand/fstream
from resources.lib.comaddon import VSlog
from resources.lib.parser import cParser
from resources.lib.handler.requestHandler import cRequestHandler


class cHosterHandler:

    def getUrl(self, oHoster):
        sUrl = oHoster.getUrl()
        VSlog("hosterhandler " + sUrl)
        oRequest = cRequestHandler(sUrl)
        sContent = oRequest.request()

        aMediaLink = cParser().parse(sContent, oHoster.getPattern())
        if (aMediaLink[0] == True):
            return True, aMediaLink[1][0]
        return False, ''

    def getHoster(self, sHosterFileName):
        exec("from resources.hosters." + sHosterFileName + " import cHoster")

        return cHoster()
