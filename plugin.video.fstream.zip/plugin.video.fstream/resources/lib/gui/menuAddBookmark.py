import xbmc
xbmc.executebuiltin("RunPlugin(plugin://plugin.video.fstream/?site=cFav&function=setBookmark)", True)
